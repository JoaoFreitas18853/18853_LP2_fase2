﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dados;
using UrgenciaBO;
using Exceptions;
using Urgencias;

namespace UrgenciaBR
{
    public class MedicList
    {
        public MedicList()
        {
        }

        public bool AddMedic(Medic medico)
        {
            try { 
            if (Medics.AddMedic(medico))
            {
                return true;
            }
            else
            {
                return false;
            }
            } 
            catch (AddException e)
            {
                throw e;
            }
        }

        public bool RemoveMedic(Medic medico)
        {
            try
            {
                if (Medics.RemoveMedic(medico))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (RemoveException e)
            {
                throw e;
            }
        }

        
        public List<Medic> GetMedicsCardiologistas()
        {
             return Medics.GetMedics("Cardiologia");
          
        }

        public List<Medic> GetMedicsPediatras()
        {
            return Medics.GetMedics("Pediatria");

        }
        public List<Medic> GetMedicsOsteopatas()
        {
            return Medics.GetMedics("Osteopatia");

        }
        public Medic GetMedic(string code)
        {
            return Medics.GetMedic(code);
        }

    }
}
