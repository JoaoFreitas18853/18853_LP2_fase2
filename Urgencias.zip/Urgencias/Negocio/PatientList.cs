﻿using System;
using System.Collections.Generic;
using System.Text;
using Dados;
using UrgenciaBO;
using Exceptions;
using System.IO;
/// <summary>
/// Autor:João Freitas
/// Descrição:Gestão de uma urgência
/// Data:12/04/2020
/// </summary>

namespace UrgenciaBO
{   /// <summary>
    /// Organização dos pacientes em listas.
    /// Uma lista com todos os pacientes.
    /// Uma lista vermelha(Maxima gravidade).
    /// Uma lista amarela(Media gravidade).
    /// Uma lista verde(Baixa gravidade).
    /// </summary>
    public class PatientList
    {
        #region Listas
     
        private List<Patient> redList;
        private List<Patient> yellowList = new List<Patient>();
        private List<Patient> greenList = new List<Patient>();


        #endregion

        #region Construtor 
        public PatientList()    //Construtor default sem argumentos
        {
            redList = new List<Patient>();
            yellowList = new List<Patient>();
            greenList = new List<Patient>();
        }
        #endregion

        #region Metodos
        ///Metodo para inserir um paciente na lista de pacientes e simultâneamente associa-lo 
        ///a uma lista de cor, consoante a gravidade.
        ///

        public bool CheckIn(Patient p) {
            try
            {

                if (Patients.AddPaciente(p) && TpConsultas.AddConsulta(p))
                {

                    if (p.Color == "red")
                    {
                        redList.Add(p);
                    }
                    if (p.Color == "yellow")
                    {
                        yellowList.Add(p);
                    }
                    if (p.Color == "green")
                    {
                        greenList.Add(p);
                    }

                    return true;
                }
                else return false;
            }
            catch (AddException e)
            {
                throw e;
            }
            
        }
        /// Permite remover um paciente da lista de pacientes e ao mesmo tempo remove-lo 
        /// da lista de cor onde está inserido. Fazendo assim o "checkout" de um paciente 
        /// da lista de pacientes em espera.
        public void CheckOut(Patient p)
        {
            Patients.RemovePaciente(p);

            if (p.Color == "red")
            {
                redList.Remove(p);
            }
            if (p.Color == "yellow")
            {
                yellowList.Remove(p);
            }
            if (p.Color == "green")
            {
                greenList.Remove(p);
            }
        }

        public Patient NextPatient(string tp)
        {
            Patient p = new Patient();

            if(redList.Count != 0)
            {

                p = redList.Find(x => x.TipoConsulta==tp );
                redList.Remove(p);
                TpConsultas.RemoveConsulta(p);
                return p;
            }
            if(yellowList.Count != 0)
            {
                p = yellowList.Find(x => x.TipoConsulta == tp);
                yellowList.Remove(p);
                TpConsultas.RemoveConsulta(p);
                return p;
            }
            if(greenList.Count != 0)
            {
                p = greenList.Find(x => x.TipoConsulta == tp);
                greenList.Remove(p);
                TpConsultas.RemoveConsulta(p);
                return p;
            }
            return null;
        }

        public Patient GetPatient(string code)
        {
            return Patients.GetPatient(code);
        }

        public bool GuardarDados(string file)
        {
            try
            {
                return Patients.GuardarDados(file);
            }
            catch (IOException)
            {
                throw new IOException();
            }
            catch (FileNotFound)
            {
                throw new FileNotFound();
            }
            catch (FileWithNoData)
            {
                throw new FileWithNoData();
            }
            catch (NoDataToStore)
            {
                throw new NoDataToStore();
            }
            catch (Exception ex)
            { // para o caso de acontecer algo nao previsto
                throw new Exception(ex.Message);
            }
        }

        public bool CarregarDados(string file)
        {
            try
            {
                return Patients.CarregarDados(file);
            }
            catch (IOException)
            {
                throw new IOException();
            }
            catch (FileNotFound)
            {
                throw new FileNotFound();
            }
            catch (FileWithNoData)
            {
                throw new FileWithNoData();
            }
            catch (Exception ex)
            { // para o caso de acontecer algo nao previsto
                throw new Exception(ex.Message);
            }

        }


        #endregion

        #region Overrides
        //Mostrar o conteudo das listas( ainda nao esta  funcionar como pretendo 
        /*  public override string ToString()
          {
              return string.Format("Lista de todos os pacientes: {0}\n Lista Vermelha: {1} \n " +
                  "Lista Amarela: {2}\n Lista verde:{3}", patients, redList, yellowList, greenList);
          }*/

        #endregion

    }
}
