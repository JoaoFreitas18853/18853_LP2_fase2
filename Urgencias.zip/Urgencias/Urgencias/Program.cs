﻿using System;
using System.IO;
using Exceptions;
using UrgenciaBO;
using UrgenciaBR;

namespace Urgencias
{
    class Program

        
        { 

        public static void MenuPatient()
        {
            Console.WriteLine("---------Menu Paciente--------");
            Console.WriteLine("1-Adicionar paciente");
            Console.WriteLine("2-Remover paciente");
            Console.WriteLine("3-Voltar ao menu principal");       
        }

        public static void MenuListaEspera()
        {
            Console.WriteLine("---------Lista de Espera--------");
            Console.WriteLine("1-Próximo paciente para Cardiologia");
            Console.WriteLine("2-Próximo paciente para Pediatria");
            Console.WriteLine("3-Próximo paciente para Osteopatia");
            Console.WriteLine("4-Voltar ao menu principal");
        }

        public static void MenuMedicos()
        {
            Console.WriteLine("---------Gestão de médicos--------");
            Console.WriteLine("1-Adicionar médico");
            Console.WriteLine("2-Remover médico");
            Console.WriteLine("3-Voltar ao menu principal");
        }
        public static void MenuListaMedicos()
        {
            Console.WriteLine("---------Listagem de médicos--------");
            Console.WriteLine("1-Cardiologia");
            Console.WriteLine("2-Pediatria");
            Console.WriteLine("3-Osteopatia");
            Console.WriteLine("4-Voltar ao menu principal");
        }

        static void Main(string[] args)

         {
            System.IO.FileStream f = System.IO.File.Create(@"C:\Users\Utilizador\Desktop\ProjetoLP2\pacientes.dat");
            string[] consultas = { "Cardiologia", "cardiologia", "Pediatria", "pediatria", "Osteopatia", "osteopatia" };
            PatientList lista = new PatientList();
            MedicList medicos = new MedicList();
            lista.CarregarDados("pacientes");


            string op = "0";
            
            while( op != "5")
            {
               
                Console.WriteLine("--------------MENU-------------");
                Console.WriteLine("1-Gegir médicos");
                Console.WriteLine("2-Listar médicos por especialidade");
                Console.WriteLine("3-Gerir pacientes");
                Console.WriteLine("4-Listas de espera");
                Console.WriteLine("5-Sair");
                Console.WriteLine("-------------------------------");
                Console.WriteLine("Insira a opção:");
                op = Console.ReadLine();
                Console.WriteLine("-------------------------------");

                switch (op)
                {
                    case "1":
                        string op1 = "0";

                        while(op1 != "3")
                        {
                            String cod, nome, esp;
                            MenuMedicos();
                            Console.WriteLine("Insira a opção:");
                            op1 = Console.ReadLine();

                            switch (op1)
                            {
                                case "1":
                                    Console.WriteLine("----Adicionar Médico----");
                                    Console.WriteLine("Insira um codigo com 5 numeros");
                                    cod = Console.ReadLine();
                                    if (medicos.GetMedic(cod) != null)
                                    {
                                        Console.WriteLine("Esse codigo já existe");
                                        break;
                                    }
                                    Console.WriteLine("Insira o nome:");
                                    nome = Console.ReadLine();
                                    if (nome == "")
                                    {
                                        Console.WriteLine("Nome inválido");
                                        break;
                                    }
                                    Console.WriteLine("Insira a especialidade:");
                                    esp = Console.ReadLine();
                                    bool verifica = false;
                                     foreach(string i in consultas)
                                    {
                                        if (esp == i)
                                        {
                                            verifica = true;
                                        }
                                    }
                                    if (!verifica) Console.WriteLine("Especialidade Inválida");
                                    
                                    Medic m = new Medic(esp, cod, nome);
                                    medicos.AddMedic(m);
                                    break;

                                case "2":
                                    Console.WriteLine("-------Remover Medico-------");
                                    Console.WriteLine("Código do Medico:");
                                    cod = Console.ReadLine();
                                    medicos.GetMedic(cod);
                                    if (medicos.GetMedic(cod) != null)
                                    {
                                        m = medicos.GetMedic(cod);
                                        medicos.RemoveMedic(m);
                                        Console.WriteLine("Removido com sucesso!");
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Nao existe nenhum medico com este codigo, tente novamente");
                                        break;
                                    }
                            }
                            
                        }
                        break;

                    case "2":
                        string op2 = "0";

                        while(op2 != "4")
                        {
                            MenuListaMedicos();
                            Console.WriteLine("Insira a opção:");
                                op2 = Console.ReadLine();

                            switch (op2)
                            {
                                case "1":
                                    foreach (Medic m in medicos.GetMedicsCardiologistas())
                                    {
                                        Console.WriteLine(m.ToString() +  "\n");
                                    }
                                    break;
                                case "2":
                                    foreach (Medic m in medicos.GetMedicsPediatras())
                                    {
                                        Console.WriteLine(m.ToString() + "\n");
                                    }
                                    break;
                                case "3":
                                    foreach (Medic m in medicos.GetMedicsOsteopatas())
                                    {
                                        Console.WriteLine(m.ToString() + "\n");
                                    }
                                    break;
                            }
                        }
                        break;


                    case "3":
                        
                        string op3 = "0";

                        while(op3 != "3")
                        {
                            String cod, nome, tp, cor;
                            int age;
                            MenuPatient();
                            Console.WriteLine("Insira a opção:");
                            op3 = Console.ReadLine();

                            switch (op3)
                            {
                                case "1":
                                    Console.WriteLine("----Adicionar Paciente----");
                                    Console.WriteLine("Insira um codigo com 5 numeros");
                                    cod = Console.ReadLine();
                                    if (lista.GetPatient(cod) != null)
                                    {
                                        Console.WriteLine("Esse codigo já existe");
                                        break;
                                    }
                                    Console.WriteLine("Insira o nome:");
                                    nome = Console.ReadLine();
                                    if(nome == "")
                                    {
                                        Console.WriteLine("Nome inválido");
                                        break;
                                    }
                                    Console.WriteLine("Insira idade:");
                                    age = Convert.ToInt32(Console.Read());
                                    if(age <= 0)
                                    {
                                        Console.WriteLine("Idade inválida");
                                        break;
                                    }
                                    Patient p1 = new Patient(cod, nome, age);


                                    Console.WriteLine("------Ficha de triagem-------");
                                    Console.WriteLine("Tipo de consulta :");
                                    Console.ReadLine();
                                    tp = Console.ReadLine();
                                    bool verifica = false;
                                    foreach (string i in consultas)
                                    {
                                        if (tp == i)
                                        {
                                            verifica = true;
                                        }
                                    }
                                    if (!verifica) Console.WriteLine("Tipo de consulta inválida");
                                    Console.WriteLine("Gravidade(red,yellow,green):");
                                    cor = Console.ReadLine();


                                 

                                   p1.CriarFicha(cor, tp);

                                    if (lista.CheckIn(p1))
                                    {
                                        Console.WriteLine("Criado com sucesso");
                                        
                                    }
                                       break;

                                case "2":
                                    Console.WriteLine("-------Remover Paciente-------");
                                    Console.WriteLine("Código do Paciente:");
                                    cod = Console.ReadLine();
                                    lista.GetPatient(cod);
                                    if (lista.GetPatient(cod) != null)
                                    {
                                        p1 = lista.GetPatient(cod);
                                        lista.CheckOut(p1);
                                        Console.WriteLine("Removido com sucesso!");
                                        break;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Nao existe nenhum paciente com este codigo, tente novamente");
                                        break;
                                    }

                                    

                            }
                          
                        }

                    break;

                    case "4":
                        string op4 = "0";

                        while(op4 != "4")
                        {
                            MenuListaEspera();
                            Console.WriteLine("Insira a opção:");
                            op4 = Console.ReadLine();

                            switch (op4)
                            {
                                case "1":
                                    Console.WriteLine("Proximo paciente:" + lista.NextPatient("Cardiologia").ToString());
                                    break;

                                case "2":
                                    Console.WriteLine("Proximo paciente:" + lista.NextPatient("Pediatria").ToString());
                                    break;

                                case "3":
                                    Console.WriteLine("Proximo paciente:" + lista.NextPatient("Osteopatia").ToString());
                                    break;

                            }

                        }

                        break;


                        







                }
            }

            lista.GuardarDados("pacientes");


            


        }
    }
}
