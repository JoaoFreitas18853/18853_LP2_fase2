﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class AddException : ApplicationException
    {
        public AddException() : base("INVÁLIDO: Inserção") { 
        }
        public AddException(string s) : base(s)
        {

        }
        public AddException (string s, Exception e)
        {
            throw new AddException("ERRO:" + s + "-->" + e.Message);
        }

    }
}
