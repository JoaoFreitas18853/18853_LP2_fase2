﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
	public class FileNotFound : ApplicationException
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Excepcoes.FileNotFound"/> class.
		/// </summary>
		public FileNotFound() : base("Ficheiro de Dados não encontrados")
		{

		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Excepcoes.FileNotFound"/> class.
		/// </summary>
		/// <param name="s">S.</param>
		public FileNotFound(string s) : base(s)
		{
			throw new ApplicationException("Ficheiro " + s + "\nNão encontrado");

		}
	}

	public class FileWithNoData : ApplicationException
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Excepcoes.FileWithNoData"/> class.
		/// </summary>
		public FileWithNoData() : base("Ficheiro sem dados")
		{

		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Excepcoes.FileWithNoData"/> class.
		/// </summary>
		/// <param name="s">S.</param>
		public FileWithNoData(string s) : base(s)
		{
			throw new ApplicationException("Ficheiro " + s + "\nNão contem dados");

		}
	}

	/// <summary>
	/// No data to store.
	/// </summary>
	public class NoDataToStore : ApplicationException
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="Excepcoes.NoDataToStore"/> class.
		/// </summary>
		public NoDataToStore() : base("Sem dados para guardar")
		{

		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Excepcoes.NoDataToStore"/> class.
		/// </summary>
		/// <param name="s">S.</param>
		public NoDataToStore(string s) : base(s)
		{
			throw new ApplicationException(s + "\nSem dados para guardar");

		}
	}

	}
