﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class RemoveException : ApplicationException
    {


        public RemoveException() : base("INVÁLIDO: Remoção")
        {
        }
        public RemoveException(string s) : base(s)
        {

        }
        public RemoveException(string s, Exception e)
        {
            throw new RemoveException("ERRO:" + s + "-->" + e.Message);
        }
    }
}
