﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
   public class DoesntExistException : ApplicationException
    {
        public DoesntExistException() : base("INVÁLIDO: Não existe!")
        {
        }
        public DoesntExistException(string s) : base(s)
        {

        }
    public DoesntExistException(string s, Exception e)
        {
            throw new DoesntExistException("ERRO:" + s + "-->" + e.Message);
        }
    }
}
