﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UrgenciaBO;
using Exceptions;

namespace Dados
{
    public class TpConsultas
    {
        private string[] consultas = { "Cardiologia", "cardiologia", "Pediatria", "pediatria", "Osteopatia", "osteopatia" };
        private static List<Patient> allCardiologia;
        private static List<Patient> allPediatria;
        private static List<Patient> allOsteopatia;

        static TpConsultas(){
            allCardiologia = new List<Patient>();
            allPediatria = new List<Patient>();
            allOsteopatia = new List<Patient>();
        }

        public static bool AddConsulta(Patient aux)
        {

            if (aux.TipoConsulta == "Cardiologia" | aux.TipoConsulta == "cardiologia")
            {
                try
                {
                    foreach (Patient p in allCardiologia)
                    {
                        if (aux.Equals(p)) return false;
                    }
                    aux.TipoConsulta = "Cardiologia";
                    allCardiologia.Add(aux);

                    return true;
                }

                catch (AddException e)
                {
                    throw e;
                }
                
           
            }

            if (aux.TipoConsulta == "Pediatria" | aux.TipoConsulta == "pediatria")
            {
                try
                {
                    foreach (Patient p in allPediatria)
                    {
                        if (aux.Equals(p)) return false;
                    }
                    aux.TipoConsulta = "Pediatria";
                    allPediatria.Add(aux);
                    return true;
                }

                catch (AddException e)
                {
                    throw e;
                }


            }
            if (aux.TipoConsulta == "Osteopatia" | aux.TipoConsulta == "osteopatia")
            {
                try
                {
                    foreach (Patient p in allOsteopatia)
                    {
                        if (aux.Equals(p)) return false;
                    }
                    aux.TipoConsulta = "Osteopatia";
                    allOsteopatia.Add(aux);
                    return true;
                }

                catch (AddException e)
                {
                    throw e;
                }


            }
            return false;
        }

        public static bool RemoveConsulta(Patient aux)
        {      
            try
            {
             
                foreach (Patient p in allCardiologia)
                {

                    if (aux.Equals(p))
                    {
                        allCardiologia.Remove(p);
                        return true;
                    }
                }

                foreach (Patient p in allPediatria)
                {

                    if (aux.Equals(p))
                    {
                        allPediatria.Remove(p);
                        return true;
                    }
                }
                foreach (Patient p in allOsteopatia)
                {

                    if (aux.Equals(p))
                    {
                        allOsteopatia.Remove(p);
                        return true;
                    }
                }
              
            }
            catch (RemoveException e)
            {
                throw e;
            }
            return false;

        }
    }
}
