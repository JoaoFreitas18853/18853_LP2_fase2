﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

using UrgenciaBO;
using Exceptions; 

namespace Dados
{
    public class Patients
    {
        private static List<Patient> allPatients; 

        static Patients()
        {
            allPatients = new List<Patient>();

        }

        public static bool AddPaciente(Patient aux)
        {
            try
            {
                foreach (Patient p in allPatients)
                {
                    if (aux.Equals(p)) return false;
                }

                allPatients.Add(aux);
            }
            catch ( AddException e)
            {
                throw e;
            }
            return true;

        }

        public static bool RemovePaciente(Patient aux)
        {
            bool removeu = false;
            try
            {
               
                foreach (Patient p in allPatients)
                {
                   
                    if (aux.Equals(p))
                        {
                        allPatients.Remove(p);
                        removeu = true;
                        }
                }
                if (removeu == false)
                {
                    return false;
                }


            }
            catch ( RemoveException e)
            {
                throw e;
            }
            return true;

        }
        public static Patient GetPatient(string code)
        {
            try
            {
                foreach (Patient p in allPatients)
                {
                    if (p.Code == code)
                    {
                        return p;
                    }

                }
            }
            catch (DoesntExistException e)

            {
                throw e;
               
            }
            return null;
        }

        public static bool GuardarDados(string fileName)
        {
            bool evalAllPatients;

            fileName = fileName + ".dat";

            try
            {
                Stream stream = File.Open(fileName, FileMode.Create);
                BinaryFormatter bin = new BinaryFormatter();
                bin.Serialize(stream, allPatients);
                stream.Close();
                evalAllPatients = true;
            }
            catch (IOException)
            {
                throw new IOException();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            if (evalAllPatients)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Loads the lugares.
        /// </summary>
        /// <returns><c>true</c>, if lugares was loaded, <c>false</c> otherwise.</returns>
        public static bool CarregarDados(string fileName)
        {
            allPatients.Clear();

            bool evalAllPatients;

            fileName = fileName + ".dat";

            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    allPatients = (List<Patient>)bin.Deserialize(stream);
                    stream.Close();
                    evalAllPatients = true;

                    if (allPatients.Count == 0) {
                        evalAllPatients = false;
                        throw new FileWithNoData(fileName);
                    }
                }
                catch (IOException)
                {
                    throw new IOException();
                }
                catch (Exception ex)
                { 
                    throw new Exception(ex.Message);
                }

            }
            else
            {
              //  BinaryWriter F = new BinaryWriter(new FileStream(@"C:\Users\Utilizador\Desktop\ProjetoLP2\pacientes.bin", FileMode.Create));
                throw new FileNotFound(fileName);
            }

            if (evalAllPatients)
            {
                return true;
            }
            return false;
        }





    }

}
