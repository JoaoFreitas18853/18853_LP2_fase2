﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using UrgenciaBO;
using Exceptions;
using Urgencias;

namespace Dados
{
    public class Medics
    {
        private static List<Medic> allMedics;
        private static List<Medic> allCardiologistas;
        private static List<Medic> allPediatras;
        private static List<Medic> allOsteopatas;

        static Medics()
        {
            allMedics = new List<Medic>();
            allCardiologistas = new List<Medic>();
            allPediatras = new List<Medic>();
            allOsteopatas = new List<Medic>();

        }

        public static bool AddMedic(Medic aux)
        {
            if (aux.Speciality == "Cardiologia" | aux.Speciality == "cardiologia")
            {
                try
                {
                    foreach (Medic m in allCardiologistas)
                    {
                        if (aux.Equals(m)) return false;
                    }
                    aux.Speciality = "Cardiologia";
                    allMedics.Add(aux);
                    allCardiologistas.Add(aux);

                    return true;
                }

                catch (AddException e)
                {
                    throw e;
                }


            }

            if (aux.Speciality == "Pediatria" | aux.Speciality == "pediatria")
            {
                try
                {
                    foreach (Medic m in allPediatras)
                    {
                        if (aux.Equals(m)) return false;
                    }
                    aux.Speciality = "Pediatria";
                    allMedics.Add(aux);
                    allPediatras.Add(aux);
                    return true;
                }

                catch (AddException e)
                {
                    throw e;
                }


            }
            if (aux.Speciality == "Osteopatia" | aux.Speciality == "osteopatia")
            {
                try
                {
                    foreach (Medic m in allOsteopatas)
                    {
                        if (aux.Equals(m)) return false;
                    }
                    aux.Speciality = "Osteopatia";
                    allMedics.Add(aux);
                    allOsteopatas.Add(aux);
                    return true;
                }

                catch (AddException e)
                {
                    throw e;
                }


            }
            return false;
        }



        public static bool RemoveMedic(Medic aux)
        {
            try
            {

                foreach (Medic m in allCardiologistas)
                {

                    if (aux.Equals(m))
                    {
                        allCardiologistas.Remove(m);
                        allMedics.Remove(m);
                        return true;
                    }
                }

                foreach (Medic m in allPediatras)
                {

                    if (aux.Equals(m))
                    {
                        allPediatras.Remove(m);
                        allMedics.Remove(m);
                        return true;
                    }
                }
                foreach (Medic m in allOsteopatas)
                {

                    if (aux.Equals(m))
                    {
                        allOsteopatas.Remove(m);
                        allMedics.Remove(m);
                        return true;
                    }
                }

            }
            catch (RemoveException e)
            {
                throw e;
            }
            return false;

        }

        public static List<Medic> GetMedics(string especialidade)
        {
            List<Medic> lista = new List<Medic>();
            try
            {
                foreach (Medic m in allMedics)
                {
                    if (m.Speciality == especialidade)
                    {
                       lista.Add(m);
                    }

                }
                return lista;
            }
            catch (DoesntExistException e)

            {
                throw e;

            }
        }

        public static Medic GetMedic(string code)
        {
            try
            {
                foreach (Medic m in allMedics)
                {
                    if (m.Code == code)
                    {
                        return m;
                    }

                }
            }
            catch (DoesntExistException e)

            {
                throw e;

            }
            return null;
        }
    }
}
